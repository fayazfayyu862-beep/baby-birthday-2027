# IsmaMuhaz — A Little World for Baby ❤️

A blush-pink, mobile-first birthday surprise for January 1, 2027 at 12:00 AM India time.

## Add your photos
Put up to 15 photos in `assets/photos/`, named exactly:
`photo-01.jpg`, `photo-02.jpg`, ... `photo-15.jpg`.

## Music
The **Play our song** button opens YouTube search for “Rathinamo Female Version Tanisha Gnanavel”. This avoids embedding an unverified upload. Before sharing, you can replace the search URL in `index.html` with the exact official video URL you prefer.

## Birthday lock limitation
The countdown uses the visitor's device clock and runs in the browser. It is suitable as a fun surprise gate, but it is not tamper-proof: visitors can change their device clock or inspect the page code. Strict enforcement needs a server-side gate.

## Publish
Upload `index.html`, `README.md`, and the complete `assets` folder to the root of your GitHub Pages repository.
