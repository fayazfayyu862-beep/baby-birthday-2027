# A Little World for Baby

A mobile-first birthday website for 1 January 2027, midnight India Standard Time.

## Preview locally
Open `index.html` in a browser. To preview the unlocked experience before the birthday, add `?preview` to the URL. This is a development preview only; do not share the preview link with Baby.

## Add your photos
Put 10–15 JPG photos in `assets/photos/` using these exact names:
- photo-01.jpg
- photo-02.jpg
...
- photo-15.jpg

Unused slots can be left empty.

## Add her favourite song
Put a music file in `assets/music/` and edit `index.html` near the bottom:
`<audio id="song" preload="none" loop></audio>`
Change it to e.g.:
`<audio id="song" preload="none" loop src="assets/music/our-song.mp3"></audio>`

Use a song file you have permission to use. Browsers require a tap before music can start.

## Personalise the words
In `index.html`, edit:
- the `messages` array for the six hidden notes
- the gift message inside `openGift()`
- the final letter in the `.letter` section

## Birthday lock
The target is set to `2027-01-01T00:00:00+05:30` (India Standard Time).
The website asks timeapi.io for the current Asia/Kolkata time and fails closed if it cannot verify the time. It checks again every 15 seconds.
Important: this is a practical early-opening guard, not tamper-proof access control. A static website's client-side code can be modified by a technically skilled visitor. A true enforced gate requires a backend/server-side check.

## Publish with GitHub Pages
1. Create a new GitHub repository, e.g. `baby-birthday`.
2. Upload `index.html` and the entire `assets` folder.
3. Open repository Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish and test the URL on mobile.
7. Share the normal website URL, not a URL containing `?preview`.

## Preview mode
Append `?preview` to your website URL to unlock the birthday experience for your own testing. Remove it before sharing. The preview flag does not change the birthday countdown; it only documents the intended developer preview. For now, to test the unlocked view locally, use browser developer tools to call `showExperience()` from the console after the page loads.
